from flask import Flask, render_template_string, jsonify, Response
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime, timedelta
import csv
import io

# Initialize Flask app
app = Flask(__name__)

# Firebase initialization
cred = credentials.Certificate(r"C:\Users\USER\flask_project\firebase_credentials.json")  # Ensure this path is correct
firebase_admin.initialize_app(cred)

# Initialize Firestore
db = firestore.client()

# Route for fetching waste data from Firestore
@app.route('/get_waste_data')
def get_waste_data():
    try:
        waste_ref = db.collection('waste_data')  # Ensure you have this collection in Firestore
        latest_waste_doc = waste_ref.order_by('time_stamp', direction=firestore.Query.DESCENDING).limit(1).stream()

        waste_data = []
        for doc in latest_waste_doc:
            data = doc.to_dict()

            model_accuracy = data.get('model_accuracy', 'N/A')
            if model_accuracy != 'N/A':
                try:
                    model_accuracy = float(model_accuracy)
                except ValueError:
                    model_accuracy = 0

            time_stamp = data.get('time_stamp', 'N/A')
            if time_stamp != 'N/A':
                try:
                    time_stamp = datetime.strptime(time_stamp, '%Y-%m-%dT%H:%M:%S.%fZ')
                except ValueError:
                    time_stamp = 'Invalid Timestamp'

            waste_data.append({
                'Image_url': data.get('image_url', 'https://via.placeholder.com/150'),
                'Waste_type': data.get('waste_type', 'N/A'),
                'Model_accuracy': model_accuracy,
                'Time_stamp': time_stamp
            })

        if not waste_data:
            waste_data = [{'Waste_type': 'N/A', 'Model_accuracy': 0, 'Image_url': 'https://via.placeholder.com/150', 'Time_stamp': 'No data'}]

        avg_accuracy = waste_data[0]['Model_accuracy']

        return jsonify({
            'waste_data': waste_data,
            'avg_accuracy': avg_accuracy
        })

    except Exception as e:
        return jsonify({'error': 'Failed to fetch data'}), 500


# Route for fetching weekly waste count data
@app.route('/get_weekly_data')
def get_weekly_data():
    try:
        today = datetime.utcnow()
        start_of_week = today - timedelta(days=today.weekday())
        start_of_week = start_of_week.replace(hour=0, minute=0, second=0, microsecond=0)

        waste_ref = db.collection('waste_data')
        weekly_waste_docs = waste_ref.stream()

        weekly_counts = {'Paper': 0, 'Plastic': 0, 'Metal': 0, 'Glass': 0}

        for doc in weekly_waste_docs:
            data = doc.to_dict()
            time_stamp = data.get('time_stamp')
            if time_stamp:
                try:
                    # Parse the Firestore timestamp string
                    time_stamp = datetime.strptime(time_stamp, '%Y-%m-%dT%H:%M:%S.%fZ')
                    # Check if the timestamp falls within the current week
                    if time_stamp >= start_of_week:
                        waste_type = data.get('waste_type', '').capitalize()
                        if waste_type in weekly_counts:
                            weekly_counts[waste_type] += 1
                except ValueError:
                    continue

        return jsonify({'weekly_counts': weekly_counts})

    except Exception as e:
        return jsonify({'error': 'Failed to fetch weekly data', 'details': str(e)}), 500


# Route for fetching the last 10 waste classifications
@app.route('/get_last_10_wastes')
def get_last_10_wastes():
    try:
        waste_ref = db.collection('waste_data')  # Ensure this collection exists in Firestore
        latest_waste_docs = waste_ref.order_by('time_stamp', direction=firestore.Query.DESCENDING).limit(10).stream()

        last_10_wastes = []
        for doc in latest_waste_docs:
            data = doc.to_dict()
            last_10_wastes.append({
                'Waste_type': data.get('waste_type', 'N/A'),
                'Model_accuracy': float(data.get('model_accuracy', 0))
            })

        return jsonify({'last_10_wastes': last_10_wastes})

    except Exception as e:
        return jsonify({'error': 'Failed to fetch last 10 wastes'}), 500


# Route for downloading the data as a CSV
@app.route('/download_csv')
def download_csv():
    try:
        waste_ref = db.collection('waste_data')
        waste_docs = waste_ref.stream()

        output = io.StringIO()
        writer = csv.writer(output)

        writer.writerow(['Image URL', 'Waste Type', 'Model Accuracy', 'Timestamp'])

        for doc in waste_docs:
            data = doc.to_dict()
            writer.writerow([
                data.get('image_url', 'N/A'),
                data.get('waste_type', 'N/A'),
                data.get('model_accuracy', '0'),
                data.get('time_stamp', 'N/A')
            ])

        output.seek(0)

        return Response(output, mimetype='text/csv', headers={
            'Content-Disposition': 'attachment;filename=waste_data.csv'
        })

    except Exception as e:
        return jsonify({'error': 'Failed to generate CSV file'}), 500


# Route for rendering the HTML page
@app.route('/')
def index():
    return render_template_string(html_template)


# Front-End Code (HTML, CSS, JS)
html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI-based Dry Waste Segregator</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url("{{ url_for('static', filename='background.png') }}");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: rgba(52, 152, 219, 0.8);
            color: white;
            text-align: center;
            padding: 20px 0;
            border-bottom: 5px solid #2980b9;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .card {
            background-color: rgba(255, 255, 255, 0.6); /* Semi-transparent background */
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }
        .table-container {
            margin: 20px 0;
            border-collapse: collapse;
            width: 100%;
        }
        .table-container th, .table-container td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        .table-container th {
            background-color: #3498db;
            color: white;
        }
        .list-container ul {
            list-style-type: none;
            padding: 0;
        }
        .list-container li {
            background-color: #ecf0f1;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
        }
        #weekly-pie-chart {
            margin: 0 auto;
            display: block;
        }
        footer {
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: 20px;
        }
        footer a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>AI-based Dry Waste Segregator</h1>
    </header>
    <div class="container">
        <div class="card">
            <h2>Latest Waste Data</h2>
            <p><strong>Model Accuracy: </strong><span id="avg-accuracy">Loading...</span></p>
            <table class="table-container">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Waste Type</th>
                        <th>Model Accuracy</th>
                    </tr>
                </thead>
                <tbody id="waste-table-body">
                    <tr><td colspan="3">Loading...</td></tr>
                </tbody>
            </table>
        </div>
        <div class="card">
            <h2>Weekly Waste Counts</h2>
            <table class="table-container">
                <thead>
                    <tr>
                        <th>Waste Type</th>
                        <th>Count</th>
                    </tr>
                </thead>
                <tbody id="weekly-table-body">
                    <tr><td colspan="2">Loading...</td></tr>
                </tbody>
            </table>
            <canvas id="weekly-pie-chart"></canvas>
        </div>
        <div class="card list-container">
            <h2>Last 10 Waste Classifications</h2>
            <ul id="last-10-waste-list">
                <li>Loading...</li>
            </ul>
        </div>
    </div>
    <footer>
        <p>&copy; 2025 AI-based Waste Segregator | <a href="/download_csv">Download Data (CSV)</a></p>
    </footer>
    <script>
        async function fetchData(url) {
            const response = await fetch(url);
            const data = await response.json();
            return data;
        }

        window.onload = async function() {
            const { waste_data, avg_accuracy } = await fetchData('/get_waste_data');
            const avgAccuracyElem = document.getElementById("avg-accuracy");
            avgAccuracyElem.innerText = avg_accuracy;

            const wasteTableBody = document.getElementById("waste-table-body");
            wasteTableBody.innerHTML = "";
            waste_data.forEach(waste => {
                wasteTableBody.innerHTML += `
                    <tr>
                        <td><img src="${waste.Image_url}" alt="Waste Image" width="50"></td>
                        <td>${waste.Waste_type}</td>
                        <td>${waste.Model_accuracy}</td>
                    </tr>
                `;
            });

            const { weekly_counts } = await fetchData('/get_weekly_data');
            const weeklyTableBody = document.getElementById("weekly-table-body");
            weeklyTableBody.innerHTML = "";
            Object.keys(weekly_counts).forEach(type => {
                weeklyTableBody.innerHTML += `
                    <tr>
                        <td>${type}</td>
                        <td>${weekly_counts[type]}</td>
                    </tr>
                `;
            });

            const ctx = document.getElementById('weekly-pie-chart').getContext('2d');
            new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: Object.keys(weekly_counts),
                    datasets: [{
                        label: 'Weekly Waste Counts',
                        data: Object.values(weekly_counts),
                        backgroundColor: ['#3498db', '#e74c3c', '#2ecc71', '#f39c12']
                    }]
                }
            });

            const { last_10_wastes } = await fetchData('/get_last_10_wastes');
            const last10List = document.getElementById("last-10-waste-list");
            last10List.innerHTML = "";
            last_10_wastes.forEach(waste => {
                last10List.innerHTML += `
                    <li>
                        Waste Type: ${waste.Waste_type}, Accuracy: ${waste.Model_accuracy}%
                    </li>
                `;
            });
        }
    </script>
</body>
</html>
"""

if __name__ == '__main__':
    app.run(debug=True)