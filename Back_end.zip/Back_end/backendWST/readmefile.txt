AI-based Dry Waste Segregator

This project is an AI-based Dry Waste Segregator that classifies dry waste types using machine learning and provides real-time data visualization through a web interface. It integrates with Firebase Firestore for data storage and management.

Features

Real-time Waste Data: Fetch the latest waste classification data, including type, model accuracy, and timestamp.

Weekly Analysis: Visualize weekly waste counts by type using a pie chart and table.

Historical Data: View the last 10 waste classifications with accuracy details.

Data Export: Download all waste classification data as a CSV file.

User Interface: A responsive web interface for visualizing waste data and analytics.

File Structure

app.py: Main application file containing Flask routes and functionalities.

firebase_credentials.json: Firebase Admin SDK service account credentials (ensure this file is present and correctly configured).

static/: Directory containing static assets like images and stylesheets.

templates/: Directory containing the HTML templates for the web interface.

requirements.txt: List of required Python packages.

Software Requirements

Python (version 3.9 or later)

Flask

Firebase Admin SDK

Chart.js (for front-end data visualization)

Web Browser (Google Chrome recommended)

Hardware Requirements

Processor: Intel i5 or equivalent (or higher)

Memory: 8GB RAM or more

Storage: At least 1GB of free disk space

Internet Connection: Required for Firebase integration

Installation

Set up a virtual environment:

python -m venv venv

Activate the virtual environment:

On Windows:

venv\Scripts\activate

On macOS/Linux:

source venv/bin/activate

Install dependencies:

pip install -r requirements.txt

Configure Firebase:

Obtain the Firebase Admin SDK JSON file from your Firebase project.

Save it as firebase_credentials.json in the project directory.

Run the application:

python app.py

Testing

Run the Flask application:

python app.py

Access the web interface:

Open a browser and navigate to http://127.0.0.1:5000.

Verify features:

Test waste data visualization, weekly analysis, and data export functionality.

Credits

Guide: Prof. Amith K S, Assistant Professor, SDMIT, Ujire