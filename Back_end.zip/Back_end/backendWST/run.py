import cv2
import numpy as np
import tensorflow as tf
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

# Firebase credentials
cred = credentials.Certificate(r"C:\Users\USER\flask_project\firebase_credentials.json")
firebase_admin.initialize_app(cred)

# Initialize Firestore client
db = firestore.client()

# Load your custom-trained model
custom_model = tf.keras.models.load_model(r"F:\backendWST\waste_classification_model.h5")

# Define class labels
class_labels = ['glass', 'metal', 'plastic', 'paper']

# Function to preprocess the image for the custom model
def preprocess_image(image):
    image = cv2.resize(image, (224, 224))
    image = image / 255.0
    image = np.expand_dims(image, axis=0)
    return image

# Function to classify the waste type using the custom model
def classify_waste(image):
    processed_image = preprocess_image(image)
    predictions = custom_model.predict(processed_image)

    predicted_class = np.argmax(predictions, axis=1)[0]
    confidence = predictions[0][predicted_class]

    waste_type = class_labels[predicted_class]
    return waste_type, confidence

# Function to upload data to Firestore with timestamp
def upload_to_firestore(waste_type, confidence):
    # Using a placeholder image URL
    placeholder_url = "https://via.placeholder.com/150"
    
    # Get current timestamp
    timestamp = datetime.utcnow().isoformat() + 'Z'  # UTC time in ISO 8601 format

    waste_data = {
        'waste_type': waste_type,
        'model_accuracy': str(round(confidence * 100, 2)),
        'image_url': placeholder_url,
        'time_stamp': timestamp  # Add timestamp field
    }

    db.collection('waste_data').add(waste_data)
    print("Data uploaded to Firestore:", waste_data)

# Capture and classify image from webcam
def capture_and_classify():
    print("Opening webcam...")
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not access the camera. Make sure it is connected and accessible.")
        return

    print("Press 'c' to capture an image and classify it. Press 'q' to quit.")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Failed to capture frame.")
            break

        cv2.imshow('Live Feed - Press "c" to Capture', frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('c'):
            print("Image captured! Classifying...")

            # Classify the waste
            waste_type, confidence = classify_waste(frame)

            # Display classification result
            text = f'Waste Type: {waste_type} ({confidence * 100:.2f}%)'
            cv2.putText(frame, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.imshow('Captured Image - Result', frame)
            cv2.waitKey(0)

            # Upload data to Firestore with timestamp
            upload_to_firestore(waste_type, confidence)

        elif key == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    try:
        capture_and_classify()
    except Exception as e:
        print(f"An error occurred: {e}")
